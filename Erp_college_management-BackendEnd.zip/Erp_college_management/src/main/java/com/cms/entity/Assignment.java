package com.cms.entity;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Set;



@Entity
@Table(name="assignment")
@NamedQuery(name="Assignment.findAll", query="SELECT r FROM Assignment r")
public class Assignment implements Serializable {
	private static final long serialVersionUID = 1L;

	private static final Set<Teacher> teacher = null;

	@Id
	
	@Column(name="assgn_id", unique=true, nullable=false)
	private int assgnId;

	@Column(name="assgn_name", length=50)
	private String assgnName;

	//bi-directional many-to-many association to 
	@ManyToMany
	@JoinTable(
		name="student_"
		, joinColumns={
			@JoinColumn(name="assgn_id", nullable=false)
			}
		, inverseJoinColumns={
			@JoinColumn(name="student_id", nullable=false)
			}
		)
	private Set<Teacher> faculty;

	public Assignment() {
	}

	public int getAssgnId() {
		return assgnId;
	}

	public void setAssgnId(int assgnId) {
		this.assgnId = assgnId;
	}

	public String getAssgnName() {
		return assgnName;
	}

	public void setAssgnName(String assgnName) {
		this.assgnName = assgnName;
	}

	public Set<Teacher> getFaculty() {
		return teacher;
	}

	public void setFaculty(Set<Teacher> faculty) {
		this.faculty = faculty;
	}

	

	
}