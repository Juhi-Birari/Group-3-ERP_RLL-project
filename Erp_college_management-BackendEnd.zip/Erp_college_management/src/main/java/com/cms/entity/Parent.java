package com.cms.entity;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
	@Table(name = "parent")
	public class Parent implements Serializable {

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	    
	    @Column(name = "name")
	    private String parentName;

	    @Column(name = "age")
	    private Integer parentAge;

	    @OneToOne(fetch = FetchType.LAZY,
	                cascade = CascadeType.ALL,
	                mappedBy = "parent")
	    private Student student;

	    @OneToMany(fetch = FetchType.LAZY,
	            cascade = CascadeType.ALL,
	            mappedBy = "parent")
	    private Set<Student> child = new HashSet<>();

	    public Parent() {}

	    public Parent(String parentName,Integer parentAge) {
	        this.parentName = parentName;
	        this.parentAge = parentAge;
	    }

	    public String getParentName() {
	        return parentName;
	    }

	    public void setParentName(String parentName) {
	        this.parentName = parentName;
	    }

	    public Integer getParentAge() {
	        return parentAge;
	    }

	    public void setParentAge(Integer parentAge) {
	        this.parentAge = parentAge;
	    }

	    public Student getHouse() {
	        return student;
	    }

	    public void setHouse(Student house) {
	        this.student = house;
	    }

	    public Set<Student> getChild() {
	        return child;
	    }

	    public void setChild(Set<Student> child) {
	        this.child = child;
	    }
	}

