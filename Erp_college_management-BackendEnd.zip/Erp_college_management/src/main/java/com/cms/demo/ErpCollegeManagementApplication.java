package com.cms.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ErpCollegeManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(ErpCollegeManagementApplication.class, args);
	}

}
