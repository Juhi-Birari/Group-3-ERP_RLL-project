package com.cms.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cms.entity.Timetable;
import com.cms.service.TimetableService;


@Controller
public class TimetableController {

	
	@Autowired
	private TimetableService timetableService ;

	
	
	@RequestMapping("/add-timetable")
	public String addcourse(HttpServletRequest request) {
		request.setAttribute("mode", "MODE_ADDSCHEDULEDATA");
		return "timetable";
	}
	
	

	@PostMapping("/timetable-saved")
	public String saveCourseIndataBase(@ModelAttribute Timetable timetable, BindingResult binding , HttpServletRequest request ){
		System.out.println("");
		timetableService.addTimetable(timetable);
		System.out.println("");
//		request.setAttribute("mode", "MODE_HOME");
		return "welcomecoursepage" ; 
	}
	
	
//	@RequestMapping("/show-timetable-to-users")
//	public String showScheduletoUsers(HttpServletRequest request) {
//		request.setAttribute("timetable", timetableService.getTimetable());
//		request.setAttribute("mode", "MODE_SHOWSCHEDULEDATA");
//		return "students";
//	}
//	
	@RequestMapping("/show-timetable")
	public String showTimetable(HttpServletRequest request) {
		request.setAttribute("timetable", timetableService.getTimetable());
//		request.setAttribute("mode", "MODE_SHOWSCHEDULEDATA");
		return "timetable";
	}
	
	
}
