package com.cms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cms.entity.Student;
import com.cms.repository.StudentRepository;
import com.cms.repository.TeacherRepository;

@Service
public class TeacherService {
	@Autowired
	private TeacherRepository teacherRepository;
	
	@Autowired
	private StudentRepository studentRepository;
	
	
	public List<Student> getAllStudents(){
		
		System.out.println("---------Get All Students--------");
		return studentRepository.findAll();
	
	}
	
	

}
