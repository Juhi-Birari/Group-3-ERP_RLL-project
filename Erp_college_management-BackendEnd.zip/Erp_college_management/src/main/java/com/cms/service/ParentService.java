package com.cms.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cms.entity.Parent;

import com.cms.repository.ParentRepository;

@Service
public class ParentService {

	@Autowired
	ParentRepository pRepo;
	
	public List<Parent> findAllDetail() {
		return pRepo.findAll();
	}
	
	public Parent findById(int id) {
		return pRepo.findById((long) id).get();
	}
	
	@Transactional
	public Parent save(Parent parent) {
		return pRepo.save(parent);
	}
}

