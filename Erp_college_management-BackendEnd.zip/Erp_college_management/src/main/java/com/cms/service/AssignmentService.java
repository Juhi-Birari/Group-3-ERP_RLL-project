package com.cms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cms.entity.Assignment;

import com.cms.repository.AssignmentRepository;


@Service
public class AssignmentService {

	@Autowired AssignmentRepository assignmentRepository;
	
	public Assignment addStudentAss(Assignment assignment) {
		return assignmentRepository.saveAndFlush(assignment);
	}

//	public Assignment addStudentAss(Assignment assignment) {
//		// TODO Auto-generated method stub
//		return null;
//	}


}
