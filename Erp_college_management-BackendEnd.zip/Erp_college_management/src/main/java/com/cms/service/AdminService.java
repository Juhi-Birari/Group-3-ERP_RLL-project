package com.cms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.cms.entity.Admin;
import com.cms.repository.*;
import com.cms.repository.*;
@Service
public class AdminService {
	

	@Autowired
	AdminRepository adminRepository;
	
	public Admin save(Admin admin)
	{
		return adminRepository.save(admin);
	}
	public List<Admin>getAll(){
		return(List<Admin>) adminRepository.findAll();
	}
	
	
	public Admin getAdminbyusername(String username) {
		return adminRepository.findByUsername(username);
	}
	
}
