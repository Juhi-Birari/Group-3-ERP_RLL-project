import { environment } from './environments/environment';


export class Configuration {
    // homePageData: './assets/student.json'
}