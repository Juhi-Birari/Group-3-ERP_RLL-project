export interface IStudentIdentificationInfo {
    firstName: string;
    lastName: string;
}