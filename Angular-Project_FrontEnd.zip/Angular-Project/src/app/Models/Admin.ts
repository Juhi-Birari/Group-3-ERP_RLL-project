export class Admin{
    public username!: string;
    public password!:string;

}